# GexanLottery
Gexan Lottery Smart-contract
